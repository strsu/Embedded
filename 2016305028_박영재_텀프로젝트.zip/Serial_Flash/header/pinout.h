/*
 * pinout.h
 *
 *  Created on: 2014. 12. 8.
 *      Author: Administrator
 */

#ifndef PINOUT_H_
#define PINOUT_H_

//*****************************************************************************
//
// Prototypes.
//
//*****************************************************************************
extern void PinoutSet(void);



#endif /* PINOUT_H_ */
